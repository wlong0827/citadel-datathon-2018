library(ggplot2)

#http://r-statistics.co/Top50-Ggplot2-Visualizations-MasterList-R-Code.html